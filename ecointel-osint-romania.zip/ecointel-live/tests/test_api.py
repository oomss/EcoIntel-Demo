import pytest
from fastapi.testclient import TestClient
from app.main import app


@pytest.fixture(scope="module")
def client():
    # Using TestClient as a context manager triggers FastAPI's lifespan
    # handler (DB init + seed) before any request is made. Without it,
    # recent Starlette versions never run startup, and every DB-backed
    # endpoint fails with "no such table".
    with TestClient(app) as c:
        yield c


def test_homepage(client):
    r = client.get('/')
    assert r.status_code == 200
    assert 'EcoIntel' in r.text

def test_summary(client):
    r = client.get('/api/summary')
    assert r.status_code == 200
    data = r.json()
    assert data['country'] == 'Romania'
    assert any(x['indicator'] == 'HICP inflation' for x in data['indicators'])

def test_series(client):
    r = client.get('/api/series?indicator=HICP%20inflation')
    assert r.status_code == 200
    data = r.json()
    assert len(data['observations']) >= 5
    assert len(data['forecast']) == 3

def test_events_and_sources(client):
    assert client.get('/api/events').json()['events']
    assert client.get('/api/sources').json()['sources']

def test_search(client):
    r = client.get('/api/search?q=inflation')
    assert r.status_code == 200
    data = r.json()
    assert data['events'] or data['observations']
