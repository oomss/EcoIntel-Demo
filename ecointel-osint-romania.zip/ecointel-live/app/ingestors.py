"""Official-source ingestion connectors for EcoIntel.

Sources:
- Eurostat REST API (JSON-stat)
- BNR daily FX XML feed
- INSSE TEMPO Online JSON service (pivot endpoint)

All connectors return normalized observations and preserve source/provenance
metadata. Network failures are raised to the caller so the ingestion command can
report partial-source failures without silently substituting synthetic values.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

import requests


@dataclass(frozen=True)
class Observation:
    country: str
    indicator: str
    period: str
    value: float
    unit: str
    source_name: str
    source_type: str
    authority_score: float
    source_url: str
    publication_date: str
    series_code: str


EUROSTAT_BASE = "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data"
# BNR now documents curs.bnr.ro as the dedicated machine-readable subdomain for
# bulk/automated XML rate retrieval (see https://curs.bnr.ro/, which specifies
# https://curs.bnr.ro/xsd/nbrfxrates.xsd as the schema). The legacy path on the
# main site (www.bnr.ro/nbrfxrates.xml) has been observed returning a WAF
# rejection ("The requested URL was rejected") for direct/automated requests,
# so this connector targets the documented subdomain instead. Override via env
# var if BNR changes this again.
BNR_FX_URL = os.getenv("BNR_FX_URL", "https://curs.bnr.ro/nbrfxrates.xml")
INSSE_BASE = os.getenv("INSSE_TEMPO_BASE", "http://statistici.insse.ro:8077/tempo-ins/")

TIMEOUT = int(os.getenv("ECOINTEL_HTTP_TIMEOUT", "30"))


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _request_json(url: str, *, params: dict[str, Any] | None = None) -> Any:
    r = requests.get(url, params=params, timeout=TIMEOUT, headers={"User-Agent": "EcoIntel/1.0"})
    r.raise_for_status()
    return r.json()


def _request_text(url: str, *, data: Any | None = None, params: dict[str, Any] | None = None) -> str:
    r = requests.post(url, json=data, timeout=TIMEOUT, headers={"User-Agent": "EcoIntel/1.0"}) if data is not None else requests.get(url, params=params, timeout=TIMEOUT, headers={"User-Agent": "EcoIntel/1.0"})
    r.raise_for_status()
    return r.text


def _jsonstat_rows(data: dict[str, Any]) -> list[dict[str, Any]]:
    """Decode Eurostat JSON-stat 2.x single/multi-series payload into rows."""
    ids = data["id"]
    sizes = data["size"]
    values = data.get("value", [])
    dims = data["dimension"]
    # sparse JSON-stat can represent values as dict keyed by flat index
    if isinstance(values, dict):
        value_map = {int(k): v for k, v in values.items()}
    else:
        value_map = {i: v for i, v in enumerate(values)}

    category_lists: list[list[tuple[str, str]]] = []
    for dim_name, size in zip(ids, sizes):
        cat = dims[dim_name]["category"]
        index = cat.get("index", {})
        if isinstance(index, list):
            ordered_codes = index
        else:
            ordered_codes = [k for k, _ in sorted(index.items(), key=lambda kv: kv[1])]
        labels = cat.get("label", {})
        category_lists.append([(code, labels.get(code, code)) for code in ordered_codes])

    rows: list[dict[str, Any]] = []
    multipliers: list[int] = []
    m = 1
    for s in reversed(sizes):
        multipliers.insert(0, m)
        m *= s

    import itertools

    for combo in itertools.product(*category_lists):
        coords = [dim_values for dim_values in combo]
        flat = sum(idx * multipliers[pos] for pos, idx in enumerate([category_lists[p].index(combo[p]) for p in range(len(ids))]))
        if flat not in value_map or value_map[flat] is None:
            continue
        row = {ids[i]: coords[i][0] for i in range(len(ids))}
        row.update({f"{ids[i]}_label": coords[i][1] for i in range(len(ids))})
        row["value"] = value_map[flat]
        rows.append(row)
    return rows


def fetch_eurostat_hicp(months: int = 36) -> list[Observation]:
    """Fetch Romania headline annual HICP inflation from current Eurostat dataset."""
    params = {
        "geo": "RO",
        "coicop18": "TOTAL",
        "unit": "RCH_A",
        "lang": "en",
        "sinceTimePeriod": f"{datetime.now().year - 4}-01",
    }
    data = _request_json(f"{EUROSTAT_BASE}/prc_hicp_minr", params=params)
    rows = _jsonstat_rows(data)
    out: list[Observation] = []
    for row in rows:
        t = row.get("time")
        if not t:
            continue
        if not re.match(r"^\d{4}-\d{2}$", t):
            continue
        out.append(Observation(
            country="Romania",
            indicator="HICP inflation",
            period=t,
            value=float(row["value"]),
            unit="% y/y",
            source_name="Eurostat",
            source_type="supranational_statistics",
            authority_score=0.97,
            source_url="https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/prc_hicp_minr",
            publication_date=_now_iso(),
            series_code="prc_hicp_minr/RO/TOTAL/RCH_A",
        ))
    out.sort(key=lambda x: x.period)
    return out[-months:]


def fetch_bnr_fx(days: int = 60) -> list[Observation]:
    """Fetch the official BNR daily EUR/RON reference rate from XML."""
    r = requests.get(BNR_FX_URL, timeout=TIMEOUT, headers={"User-Agent": "EcoIntel/1.0"})
    r.raise_for_status()
    root = ET.fromstring(r.content)
    out: list[Observation] = []
    for cube in root.findall(".//{*}Cube[@date]"):
        date = cube.attrib["date"]
        for rate in cube.findall("{*}Rate"):
            if rate.attrib.get("currency") != "EUR":
                continue
            try:
                value = float(rate.text.replace(",", "."))
            except (TypeError, ValueError):
                continue
            out.append(Observation(
                country="Romania",
                indicator="EUR/RON reference rate",
                period=date,
                value=value,
                unit="RON per EUR",
                source_name="Banca Națională a României (BNR)",
                source_type="central_bank",
                authority_score=0.98,
                source_url=BNR_FX_URL,
                publication_date=_now_iso(),
                series_code="BNR/EURRON",
            ))
    return out[-days:]


def _find_dim(dimensions: list[dict[str, Any]], label_hint: str) -> dict[str, Any] | None:
    hint = label_hint.lower()
    for d in dimensions:
        if hint in d.get("label", "").lower():
            return d
    return None


def _select_option(dim: dict[str, Any], hints: Iterable[str], *, last: bool = False) -> dict[str, Any] | None:
    options = dim.get("options", [])
    hints = [h.lower() for h in hints]
    matches = [o for o in options if any(h in str(o.get("label", "")).lower() for h in hints)]
    if not matches:
        return None
    return matches[-1] if last else matches[0]


def _parse_tempo_response(text: str) -> list[dict[str, Any]]:
    stripped = text.strip()
    if not stripped:
        return []
    try:
        payload = json.loads(stripped)
        if isinstance(payload, list):
            return payload
        if isinstance(payload, dict):
            for key in ("data", "rows", "result", "table"):
                if isinstance(payload.get(key), list):
                    return payload[key]
            return [payload]
    except json.JSONDecodeError:
        pass
    # TEMPO pivot responses have appeared as tabular text in different service versions.
    lines = [x for x in stripped.splitlines() if x.strip()]
    if len(lines) >= 2:
        dialect = csv.Sniffer().sniff("\n".join(lines[:5]), delimiters=",;\t|")
        return list(csv.DictReader(io.StringIO(stripped), dialect=dialect))
    return []


def fetch_ins_unemployment(months: int = 36) -> list[Observation]:
    """Fetch Romania's registered unemployment rate from INSSE TEMPO (SOM103A).

    TEMPO exposes metadata at /matrix/{code} and a selection endpoint at /pivot.
    The selector is built from the live dimension metadata instead of hard-coding
    opaque option IDs.
    """
    code = "SOM103A"
    base = INSSE_BASE.rstrip("/") + "/"
    meta = _request_json(base + f"matrix/{code}")
    dimensions = meta.get("dimensionsMap", [])
    if not dimensions:
        raise RuntimeError("INSSE returned no dimensions for SOM103A")

    selections: list[str] = []
    selected_labels: list[str] = []
    for dim in dimensions:
        label = dim.get("label", "")
        opts = dim.get("options", [])
        if "sex" in label.lower():
            opt = _select_option(dim, ["Total", "total"])
        elif "macroreg" in label.lower() or "regiuni" in label.lower() or "judet" in label.lower():
            opt = _select_option(dim, ["Total", "Romania", "ROMANIA"])
        elif "perioad" in label.lower():
            # Keep all period options; the service will return the full monthly history.
            selections.append(",".join(str(o["nomItemId"]) for o in opts))
            selected_labels.append(label)
            continue
        elif "um" in label.lower() or "unit" in label.lower():
            opt = _select_option(dim, ["%", "procent", "rate"])
        else:
            # Prefer the first explicit Total option when present; otherwise first option.
            opt = _select_option(dim, ["Total", "total"]) or (opts[0] if opts else None)
        if opt is None:
            raise RuntimeError(f"Could not determine INSSE selection for dimension: {label}")
        selections.append(str(opt["nomItemId"]))
        selected_labels.append(label)

    details = meta.get("details", {})
    payload = {
        "encQuery": ":".join(selections),
        "language": "ro",
        "matCode": code,
        "matMaxDim": details.get("matMaxDim", len(dimensions)),
        "matRegJ": details.get("matRegJ", 0),
        "matUMSpec": details.get("matUMSpec", 0),
    }
    raw = _request_text(base + "pivot", data=payload)
    rows = _parse_tempo_response(raw)
    out: list[Observation] = []
    for row in rows:
        flat = {str(k).lower().strip(): v for k, v in row.items()}
        value = None
        for key in ("valoare", "value", "val"): 
            if key in flat:
                value = flat[key]
                break
        period = None
        for key in flat:
            if "perioad" in key or key == "period":
                period = flat[key]
                break
        if value in (None, "", "-") or period in (None, ""):
            continue
        try:
            value_f = float(str(value).replace(",", "."))
        except ValueError:
            continue
        # Normalize Romanian TEMPO period labels to YYYY-MM where possible.
        m = re.search(r"(20\d{2})[^0-9]?(0?[1-9]|1[0-2])", str(period))
        if m:
            normalized_period = f"{m.group(1)}-{int(m.group(2)):02d}"
        else:
            continue
        out.append(Observation(
            country="Romania",
            indicator="Registered unemployment rate",
            period=normalized_period,
            value=value_f,
            unit="%",
            source_name="Institutul Național de Statistică (INS)",
            source_type="national_statistics",
            authority_score=0.98,
            source_url=f"http://statistici.insse.ro:8077/tempo-online/#/pages/tables/insse-table?ind={code}",
            publication_date=str(meta.get("ultimaActualizare", _now_iso())),
            series_code=code,
        ))
    # Deduplicate in case the pivot returns repeated dimensions.
    dedup = {(x.period, x.value): x for x in out}
    return sorted(dedup.values(), key=lambda x: x.period)[-months:]
