from statistics import mean
from typing import List, Dict


def pct_change(old: float, new: float):
    if old == 0:
        return None
    return (new - old) / abs(old) * 100


def linear_forecast(values: List[float], horizon: int = 3):
    """Simple least-squares linear trend forecast; intentionally transparent for the demo."""
    if len(values) < 2:
        return [values[-1]] * horizon
    n = len(values)
    xs = list(range(n))
    x_bar = mean(xs)
    y_bar = mean(values)
    denom = sum((x - x_bar) ** 2 for x in xs)
    slope = sum((x - x_bar) * (y - y_bar) for x, y in zip(xs, values)) / denom if denom else 0
    intercept = y_bar - slope * x_bar
    return [round(intercept + slope * (n + i), 2) for i in range(horizon)]


def zscore_latest(values: List[float]):
    if len(values) < 3:
        return 0.0
    avg = mean(values[:-1])
    var = mean([(x - avg) ** 2 for x in values[:-1]])
    std = var ** 0.5
    return 0.0 if std == 0 else (values[-1] - avg) / std


def risk_level(score: float):
    if score >= 0.75:
        return "HIGH"
    if score >= 0.45:
        return "MEDIUM"
    return "LOW"


def build_risk_snapshot(series: Dict[str, List[float]]):
    inflation = series.get("HICP inflation", [])
    unemployment = series.get("Registered unemployment rate", [])
    wage = series.get("Nominal wage growth", [])
    inflation_accel = 0
    if len(inflation) >= 3:
        inflation_accel = (inflation[-1] - inflation[-2]) + (inflation[-2] - inflation[-3])
    wage_pressure = min(max((wage[-1] / 12.0), 0), 1) if wage else 0
    labour_deterioration = min(max((unemployment[-1] - unemployment[0]) / 2.0, 0), 1) if unemployment else 0
    inflation_risk = min(max(0.65 + inflation_accel / 2.0, 0), 1)
    growth_risk = min(max(0.25 + labour_deterioration * 0.6, 0), 1)
    wage_risk = min(max(wage_pressure, 0), 1)
    return {
        "inflation": {"score": round(inflation_risk, 2), "level": risk_level(inflation_risk)},
        "growth": {"score": round(growth_risk, 2), "level": risk_level(growth_risk)},
        "wage_pressure": {"score": round(wage_risk, 2), "level": risk_level(wage_risk)},
    }
