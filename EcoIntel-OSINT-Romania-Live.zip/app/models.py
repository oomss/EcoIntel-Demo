from dataclasses import dataclass
from typing import Optional

@dataclass
class Observation:
    id: int
    country: str
    indicator: str
    period: str
    value: float
    unit: str
    source_id: int
    source_name: str
    source_url: str
    publication_date: str

@dataclass
class Event:
    id: int
    country: str
    event_date: str
    title: str
    event_type: str
    description: str
    confidence: float
    source_id: int

@dataclass
class Source:
    id: int
    name: str
    source_type: str
    authority_score: float
    url: str
