from fastapi import FastAPI, Query
from contextlib import asynccontextmanager
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from app.db import connect, init_db
from app.seed import seed
from app.analytics import linear_forecast, zscore_latest, build_risk_snapshot, pct_change

ROOT = Path(__file__).resolve().parent
@asynccontextmanager
async def lifespan(app):
    init_db()
    conn = connect()
    count = conn.execute("SELECT COUNT(*) AS c FROM observations").fetchone()["c"]
    conn.close()
    if count == 0:
        seed()
    yield

app = FastAPI(title="EcoIntel OSINT", version="2.0.0", description="Source-traceable economic OSINT platform for Romania", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

@app.get("/", include_in_schema=False)
def index():
    return FileResponse(ROOT / "static" / "index.html")

@app.get("/api/summary")
def summary():
    conn = connect()
    latest = conn.execute("""
        SELECT o.*, s.name AS source_name, s.authority_score
        FROM observations o JOIN sources s ON s.id=o.source_id
        WHERE o.country='Romania'
        ORDER BY o.period DESC, o.id DESC
    """).fetchall()
    chosen = {}
    for row in latest:
        chosen.setdefault(row["indicator"], dict(row))
    conn.close()
    return {"country": "Romania", "indicators": list(chosen.values())}

@app.get("/api/series")
def series(indicator: str = Query("HICP inflation"), country: str = Query("Romania")):
    conn = connect()
    rows = conn.execute("""
        SELECT period, value, unit, source_id, publication_date
        FROM observations WHERE country=? AND indicator=? ORDER BY period
    """, (country, indicator)).fetchall()
    conn.close()
    values = [r["value"] for r in rows]
    forecast = linear_forecast(values, 3) if values else []
    return {"country": country, "indicator": indicator, "observations": [dict(r) for r in rows], "forecast": forecast,
            "latest_change_pct": round(pct_change(values[-2], values[-1]), 2) if len(values) >= 2 else None,
            "latest_zscore": round(zscore_latest(values), 2) if values else 0}

@app.get("/api/events")
def events(limit: int = Query(10, ge=1, le=50)):
    conn = connect()
    rows = conn.execute("""
        SELECT e.*, s.name AS source_name, s.url AS source_url, s.authority_score
        FROM events e JOIN sources s ON s.id=e.source_id
        ORDER BY e.event_date DESC LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return {"events": [dict(r) for r in rows]}

@app.get("/api/sources")
def sources():
    conn = connect()
    rows = conn.execute("SELECT * FROM sources ORDER BY authority_score DESC").fetchall()
    conn.close()
    return {"sources": [dict(r) for r in rows]}

@app.get("/api/risks")
def risks():
    conn = connect()
    indicators = ["HICP inflation", "Registered unemployment rate"]
    series = {}
    for indicator in indicators:
        rows = conn.execute("SELECT value FROM observations WHERE country='Romania' AND indicator=? ORDER BY period", (indicator,)).fetchall()
        series[indicator] = [r["value"] for r in rows]
    conn.close()
    return build_risk_snapshot(series)

@app.get("/api/search")
def search(q: str = Query(..., min_length=2)):
    term = f"%{q}%"
    conn = connect()
    event_rows = conn.execute("""
        SELECT e.*, s.name AS source_name, s.url AS source_url
        FROM events e JOIN sources s ON s.id=e.source_id
        WHERE e.title LIKE ? OR e.description LIKE ? OR e.event_type LIKE ?
        ORDER BY e.event_date DESC
    """, (term, term, term)).fetchall()
    obs_rows = conn.execute("""
        SELECT o.*, s.name AS source_name, s.url AS source_url
        FROM observations o JOIN sources s ON s.id=o.source_id
        WHERE o.indicator LIKE ? OR o.country LIKE ?
        ORDER BY o.period DESC
    """, (term, term)).fetchall()
    conn.close()
    return {"query": q, "events": [dict(r) for r in event_rows], "observations": [dict(r) for r in obs_rows]}
