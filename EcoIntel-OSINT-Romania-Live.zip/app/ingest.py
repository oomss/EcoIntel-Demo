from __future__ import annotations

import argparse
from datetime import datetime, timezone

from app.db import connect, init_db
from app.ingestors import fetch_bnr_fx, fetch_eurostat_hicp, fetch_ins_unemployment


def _upsert_source(conn, name, source_type, authority, url):
    row = conn.execute("SELECT id FROM sources WHERE name=?", (name,)).fetchone()
    if row:
        conn.execute("UPDATE sources SET source_type=?, authority_score=?, url=? WHERE id=?", (source_type, authority, url, row["id"]))
        return row["id"]
    cur = conn.execute("INSERT INTO sources(name,source_type,authority_score,url) VALUES (?,?,?,?)", (name,source_type,authority,url))
    return cur.lastrowid


def _replace_series(obs):
    if not obs:
        return
    retrieved = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    conn = connect()
    indicator = obs[0].indicator
    conn.execute("DELETE FROM observations WHERE country=? AND indicator=?", (obs[0].country, indicator))
    for o in obs:
        source_id = _upsert_source(conn, o.source_name, o.source_type, o.authority_score, o.source_url)
        conn.execute("""
            INSERT INTO observations(
                country,indicator,period,value,unit,source_id,publication_date,retrieved_at,series_code
            ) VALUES (?,?,?,?,?,?,?,?,?)
        """, (
            o.country, o.indicator, o.period, o.value, o.unit, source_id,
            o.publication_date, retrieved, o.series_code,
        ))
    conn.commit()
    conn.close()


def run(sources: list[str]) -> dict[str, str]:
    init_db()
    tasks = {
        "eurostat": (fetch_eurostat_hicp, "HICP"),
        "bnr": (fetch_bnr_fx, "EUR/RON"),
        "ins": (fetch_ins_unemployment, "registered unemployment"),
    }
    results: dict[str, str] = {}
    for key in sources:
        fn, label = tasks[key]
        try:
            obs = fn()
            _replace_series(obs)
            results[key] = f"ok: {len(obs)} observations ({label})"
        except Exception as exc:
            results[key] = f"error: {type(exc).__name__}: {exc}"
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ingest official Romanian/economic data into EcoIntel")
    parser.add_argument("--source", choices=["eurostat", "bnr", "ins", "all"], default="all")
    args = parser.parse_args()
    selected = ["eurostat", "bnr", "ins"] if args.source == "all" else [args.source]
    for key, msg in run(selected).items():
        print(f"{key}: {msg}")
