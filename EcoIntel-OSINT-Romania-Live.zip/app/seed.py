"""Offline fallback dataset.

This file is intentionally synthetic. It exists only so the UI and tests can run
without network access. For real data, run `python -m app.ingest --source all`.
"""
from app.db import connect, init_db

SOURCES = [
    (1, "Institutul Național de Statistică (INS)", "national_statistics", 0.98, "https://insse.ro/"),
    (2, "Banca Națională a României (BNR)", "central_bank", 0.98, "https://www.bnr.ro/"),
    (3, "Eurostat", "supranational_statistics", 0.97, "https://ec.europa.eu/eurostat/"),
]

OBSERVATIONS = [
    (1, "Romania", "HICP inflation", "2026-01", 8.4, "% y/y", 3, "offline-demo"),
    (2, "Romania", "HICP inflation", "2026-02", 8.3, "% y/y", 3, "offline-demo"),
    (3, "Romania", "HICP inflation", "2026-03", 9.0, "% y/y", 3, "offline-demo"),
    (4, "Romania", "HICP inflation", "2026-04", 8.6, "% y/y", 3, "offline-demo"),
    (5, "Romania", "HICP inflation", "2026-05", 8.4, "% y/y", 3, "offline-demo"),
    (6, "Romania", "HICP inflation", "2026-06", 7.9, "% y/y", 3, "offline-demo"),
    (7, "Romania", "Registered unemployment rate", "2026-01", 3.5, "%", 1, "offline-demo"),
    (8, "Romania", "Registered unemployment rate", "2026-02", 3.5, "%", 1, "offline-demo"),
    (9, "Romania", "Registered unemployment rate", "2026-03", 3.4, "%", 1, "offline-demo"),
    (10, "Romania", "Registered unemployment rate", "2026-04", 3.3, "%", 1, "offline-demo"),
    (11, "Romania", "Registered unemployment rate", "2026-05", 3.2, "%", 1, "offline-demo"),
    (12, "Romania", "EUR/RON reference rate", "2026-06-29", 5.12, "RON per EUR", 2, "offline-demo"),
    (13, "Romania", "EUR/RON reference rate", "2026-06-30", 5.11, "RON per EUR", 2, "offline-demo"),
    (14, "Romania", "EUR/RON reference rate", "2026-07-01", 5.10, "RON per EUR", 2, "offline-demo"),
]

EVENTS = [
    (1, "Romania", "2026-08-01", "Live ingestion is available", "system", "Run the official-source ingestion command to replace the offline fallback observations with current Eurostat, BNR and INSSE data.", 1.0, 3),
]


def seed():
    init_db()
    conn = connect()
    conn.execute("DELETE FROM observations")
    conn.execute("DELETE FROM events")
    conn.execute("DELETE FROM investigations")
    conn.executemany("INSERT OR REPLACE INTO sources(id,name,source_type,authority_score,url) VALUES (?,?,?,?,?)", SOURCES)
    conn.executemany("INSERT OR REPLACE INTO observations(id,country,indicator,period,value,unit,source_id,publication_date) VALUES (?,?,?,?,?,?,?,?)", OBSERVATIONS)
    conn.executemany("INSERT OR REPLACE INTO events VALUES (?, ?, ?, ?, ?, ?, ?, ?)", EVENTS)
    conn.execute("INSERT OR REPLACE INTO investigations VALUES (?, ?, ?, ?, ?)", (1, "Romanian inflation monitoring", "Track whether current inflation and labour-market signals remain consistent across official sources.", "2026-08-01", "active"))
    conn.commit()
    conn.close()

if __name__ == "__main__":
    seed()
    print("Seeded offline demo database")
