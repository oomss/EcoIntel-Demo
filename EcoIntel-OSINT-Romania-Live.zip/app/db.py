import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "economic_osint.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS sources (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    source_type TEXT NOT NULL,
    authority_score REAL NOT NULL,
    url TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS observations (
    id INTEGER PRIMARY KEY,
    country TEXT NOT NULL,
    indicator TEXT NOT NULL,
    period TEXT NOT NULL,
    value REAL NOT NULL,
    unit TEXT NOT NULL,
    source_id INTEGER NOT NULL,
    publication_date TEXT NOT NULL,
    retrieved_at TEXT NOT NULL DEFAULT '',
    series_code TEXT NOT NULL DEFAULT '',
    FOREIGN KEY(source_id) REFERENCES sources(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_obs_natural_key ON observations(country, indicator, period, source_id);
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY,
    country TEXT NOT NULL,
    event_date TEXT NOT NULL,
    title TEXT NOT NULL,
    event_type TEXT NOT NULL,
    description TEXT NOT NULL,
    confidence REAL NOT NULL,
    source_id INTEGER NOT NULL,
    FOREIGN KEY(source_id) REFERENCES sources(id)
);
CREATE TABLE IF NOT EXISTS investigations (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    hypothesis TEXT NOT NULL,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL
);
"""

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = connect()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()
