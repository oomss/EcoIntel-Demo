from app.ingestors import _jsonstat_rows, _parse_tempo_response


def test_jsonstat_decoder():
    payload = {
        "id": ["geo", "time"],
        "size": [1, 2],
        "dimension": {
            "geo": {"category": {"index": {"RO": 0}, "label": {"RO": "Romania"}}},
            "time": {"category": {"index": {"2026-01": 0, "2026-02": 1}, "label": {"2026-01": "Jan 2026", "2026-02": "Feb 2026"}}},
        },
        "value": [8.1, 8.4],
    }
    rows = _jsonstat_rows(payload)
    assert [r["time"] for r in rows] == ["2026-01", "2026-02"]
    assert [r["value"] for r in rows] == [8.1, 8.4]


def test_tempo_json_rows():
    rows = _parse_tempo_response('{"rows":[{"Perioade":"2026-01","Valoare":"3,5"}]}')
    assert rows[0]["Perioade"] == "2026-01"


def test_tempo_csv_rows():
    rows = _parse_tempo_response('Perioade;Valoare\n2026-01;3,5\n2026-02;3,4\n')
    assert len(rows) == 2
    assert rows[1]["Valoare"] == "3,4"
