from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_homepage():
    r = client.get('/')
    assert r.status_code == 200
    assert 'EcoIntel' in r.text

def test_summary():
    r = client.get('/api/summary')
    assert r.status_code == 200
    data = r.json()
    assert data['country'] == 'Romania'
    assert any(x['indicator'] == 'HICP inflation' for x in data['indicators'])

def test_series():
    r = client.get('/api/series?indicator=HICP%20inflation')
    assert r.status_code == 200
    data = r.json()
    assert len(data['observations']) >= 5
    assert len(data['forecast']) == 3

def test_events_and_sources():
    assert client.get('/api/events').json()['events']
    assert client.get('/api/sources').json()['sources']

def test_search():
    r = client.get('/api/search?q=inflation')
    assert r.status_code == 200
    data = r.json()
    assert data['events'] or data['observations']
